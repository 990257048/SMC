/* @flow */

import Vue from './runtime/index'

export default Vue
