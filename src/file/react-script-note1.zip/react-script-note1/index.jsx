// React ReactDOM jsx createStore connect 

let reducer = (state = {
    v: '1'
}, action) => {
    switch(action.type){
        case "SETV":
            return { ...state, v: action.v }
        default:
            return state;
    }
}

let store = createStore(reducer);

// 组件传参
// 渲染机制
// DIFF
// 优化策略

// 优化： 减少DIFF次数（减少计算开销：DIFF策略，memo, useMemo, useCallback, pureComponent, shouldComponentUpdate ）

// 渲染机制： (实测)
// 组件依赖的状态发生变化，组件必定重新渲染，无论是内部状态还是全局状态，无论用props还是hooks。
// 父组件发生渲染，子组件必发生渲染，无论子组件状态有没有发生变化。


class App extends React.Component {
    constructor(...args){
        super(...args);
    }
    
    render(){
        console.log("app render");
        let {v, setv} = this.props;
        return <div>
            <input type="text" value={ v } onChange={ e => { setv(e.target.value) } } />
            <B setv={ v => {setv(v)} } />
        </div>
    }
}

App = connect(state => {
    return {
        v: state.v
    }
}, dispatch => {
    return {
        setv: v => {
            dispatch({type: "SETV", v});
        }
    }
})(App); 


class B extends React.Component {   // 使用PureComponent 会自动进行
    shouldComponentUpdate(nextProps){
        console.log('t:',this.props.setv, 'n:',nextProps.setv);
        return !(this.props.setv == nextProps.setv);
    }
    render(){
        console.log("B render");
        let {setv} = this.props;
        return <button onClick={ () => { setv('xxx') } }>xxxxxxxx</button>
    }
}























// let App = props => {
//     console.log("app render!");
//     let {v, setv} = props;
//     return <div>
//         <input type="text" value={ v } onChange={ e => { setv(e.target.value) } } />
//         <Btn />
//         <Father />
//     </div>
// }

// App = connect(state => {
//     return {
//         v: state.v
//     }
// }, dispatch => {
//     return {
//         setv: v => {
//             dispatch({type: "SETV", v});
//         }
//     }
// })(App); 



let Btn = () => {
    console.log("btn render!");
    return <button>click me!</button>
}

Btn = React.memo(Btn);

let Father = () => {
    console.log("father render!");
    return <div>
        <Son />
    </div>
}
Father = React.memo(Father);

let Son = () => {
    // React.useEffect(() => {
    //     console.log("son effect");
    // }, []);
    console.log("son render!");
    return <button>son</button>
}
Son = React.memo(Son);





















ReactDOM.render(
    <Provider store={store}>
        <App />    
    </Provider>,
    document.getElementById("root")
);