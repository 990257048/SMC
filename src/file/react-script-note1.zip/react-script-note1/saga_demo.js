
let {call, put, select, throttle, all, race} = ReduxSagaEffects;

let rootSaga = function* () {
    console.log('run saga!')
}

let reducer = (state = {
    val: 'app'
}, action) => {
    switch(action.type){
        case 'SET_VAL':
            var val = action.val;
            return {...state, val}
        default: 
            return state;
    }
}

let rootReducer = combineReducers({reducer});

let enhancer = applyMiddleware(thunk, sagaMiddleware);

let store = createStore(rootReducer, enhancer);

sagaMiddleware.run(rootSaga);
