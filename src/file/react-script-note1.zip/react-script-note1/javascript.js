//堆【引用】栈【基本类型】内存

// let a = {}, b = '0', c = 0;
// a[b] = 'b';
// a[c] = 'c';
// console.log(a[b])  // 'c'   属性名不能重复  数字属性名 === 字符串属性名

// let a = {}, b = Symbol('1'), c = Symbol('1');
// a[b] = 'b';
// a[c] = 'c';
// console.log(a[b]); // 'b'

// let a = {}, b = {n: '1'}, c = {m: '2'};
// a[b] = 'b';  // a['[object object]'] = 'b'  对象属性名会变成字符串 '[object object]'
// a[c] = 'c';  // a['[object object]'] = 'c'
// console.log(a[b]); // 'c'


//变量 类型 返回值
// var a = 0, b = 0;
// function A(a){
//     A = function (b){
//         alert(a + b++);
//     }
//     alert(a++);
// }
// A(1);   // '1'
// A(2);   // '4'


//对象数组深浅克隆
// let a = {
//     a: 100,
//     b: { 'm': 10 },
//     c: [ 'a', 'b', 'c'],
//     d: /^\d+$/,
//     e: function (){
//         return 1
//     }
// }
// function clone1(obj) {  //浅克隆（只克隆一层）
//     let obj2 = {};
//     for(var key in obj){
//         if( obj.hasOwnProperty(key) ){
//             obj2[key] = obj[key];
//         }
//     }
//     return obj2;
// }
// function deepClone1(obj) {   //部分类型不能深拷贝，如函数，正则
//     return JSON.parse(JSON.stringify(obj)) 
// }
function deepClone(obj) {   //比较标准的深克隆
    if(obj === null) return null;
    if(typeof obj !== 'object') return obj;
    if(obj instanceof RegExp){
        return new RegExp(obj);
    }
    if(obj instanceof Date){
        return new Date(obj);
    }
    // ...有别的类型再追加
    let newObj = new obj.constructor();
    for(let key in obj){ // fn obj arr
        if(obj.hasOwnProperty(key)){
            newObj[key] = deepClone(obj[key]);
        }
    }
    return newObj;
}
// let c_a = deepClone(a);

// 变量提升 new 优先级
// function Foo(){
//     getName = function () { console.log(1) }
//     return this;
// }
// Foo.getName = function () { console.log(2) }
// Foo.prototype.getName = function () { console.log(3) }
// var getName = function () { console.log(4) }
// function getName () { console.log(5) }
// Foo.getName();  // 2
// getName();  // 4
// Foo().getName(); // 1
// getName(); // 1
// new Foo.getName(); // 2
// new Foo().getName();  // 3  (new Foo()).getName()
// new new Foo().getName();  // 3  new (new Foo()).getName()


// 同步 异步
// promise async await 微任务
// 定时 延时 事件绑定 ajax 宏任务
// 先执行 微任务 后执行宏任务 
// 主线程 微任务 宏任务
// async function async1 () {
//     console.log('async1 start'); // 2
//     await async2 ();
//     console.log('async1 end'); // 7 | 6
// }
// async function async2 () {
//     console.log('async2'); // 3
// }
// console.log('script start');  // 1
// setTimeout(function () {
//     console.log('setTimeout 0'); // 8
// }, 0);
// async1();
// new Promise(function (resolve){
//     console.log('promise1'); // 4
//     resolve()
// }).then(function () {
//     console.log('promise2');  // 6 | 7
// });
// console.log('script end');  // 5


// 作用域 this
// var x = 2;
// var y = {
//     x: 3,
//     z: (function (x){ // 2 window 
//         this.x *= x; //window.x = 4
//         x += 2;  // 域内x = 4     第二次域内x = 7
//         return function (n){
//             this.x *= n;  // window.x = 16  第二次this = y, this.x = 15
//             x += 3; // 域内x = 7   第二次域内x = 10
//             console.log(x);
//         }
//     })(x)
// }
// var m = y.z;
// m(4); // 7
// y.z(5); // 10
// console.log(x, y.x); // 16 15


// == 隐式转换类型(obj == number 会让 obj.valueOf | obj.toString执行后的结果再比较)
// var a = ? a是什么让条件成立 
// var a = {
//     i: 0,
//     toString() {
//         return ++this.i;
//     }
// } // 或者用 defineProperty劫持a 取值的时候就加1
// if(a == 1 && a == 2 && a == 3){
//     console.log('条件成立');
// }

//==========================================================================================================

// function Foo(){
//     getName = function () { console.log(1) }
//     return this;
// }
// Foo.getName = function () { console.log(2) }
// Foo.prototype.getName = function () { console.log(3) }
// var getName = function () { console.log(4) }
// function getName () { console.log(5) }
// Foo.getName(); // 2
// getName(); // 4
// Foo().getName();   // 1 
// getName();  // 1
// new Foo.getName();  // 2
// new Foo().getName();  // 3
// new new Foo().getName();  // 3


var x = 2;
var y = {
    x: 3,
    z: (function (x){
        this.x *= x;  //win.x: 4
        x += 2;  //x: 4
        return function (n){ 
            this.x *= n; //y.x: 15 
            x += 3;   //10
            console.log(x);
        }
    })(x)
}
var m = y.z;
m(4); // 7
y.z(5); // 10
console.log(x, y.x); // 16 15


// //函数作用域的变量提升(if内部同样能被提升)
// function demo () {
//     var a = false;
//     if(a){
//         var b = 123;
//         function c(){}
//     }
//     console.log(b, c)
// }
// demo();

