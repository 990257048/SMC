// setState原理  原生同步单个 代理异步批量


class App extends React.Component {
    constructor(...args){
        super(...args);
        this.state = {
            val: 0
        }
    }
    
    // addCount(){    // 这种执行多次最终只会变成1
    //     this.setState({
    //         val: this.state.val + 1    //基于this.state.value 加 1，每次调用都会冲突
    //     })
    // }

    addCount(){    //这种执行n次就加n
        this.setState(prevState => {
            return { val: prevState.val + 1 }   // 基于上一次的结果（异步合并状态时代表上一次合并状态的计算结果，同步执行代表上一次的状态）加 1， 每次调用不会冲突
        })
    }

    clickHandle(){   // 点击事件的事件处理函数被React事件代理，会使setState异步执行，能合并状态。
        this.addCount()
        this.addCount()
        this.addCount()
    }

    render(){
        return <div>
            <button onClick={ this.clickHandle.bind(this) }>add</button> { this.state.val }
        </div>
    }
}


// class App extends React.Component {
//     constructor(...args){
//         super(...args);
//         this.state = {
//             val: 0
//         }
//     }
//     addVal(){
//         // this.setState({val: this.state.val + 2})
//         this.setState(prevState => {
//             return { val: prevState.val + 1 }
//         })
//     }
//     componentDidMount(){
//         console.log(this);
//         this.addVal()
//         console.log('1', this.state.val)
//         this.addVal()
//         console.log('2', this.state.val)
//         this.addVal()
//         console.log('3', this.state.val)
//         setTimeout(() => {
//             this.addVal()
//             console.log('4', this.state.val)
//             this.addVal()
//             console.log('5', this.state.val)
//         }, 0);
//     }
//     render(){
//         return <div>
//             app
//         </div>
//     }
// }

ReactDOM.render(
    <App />,
    document.getElementById("root")
);