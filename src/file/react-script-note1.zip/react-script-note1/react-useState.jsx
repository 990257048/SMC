
let App = () => { // App: () => ReactNode  <==>  () => React.createElement()
    let [n, setN] = React.useState(0);
    return <div>
        {n}
        <button onClick={ () => {setN(n+1)} }>+1</button>
    </div>
}

ReactDOM.render(
    <App />,
    document.getElementById("root")
);