
let SET_VAL = '设置值';
let ADD_VAL = '值加一';
let set_val = val => ({ type: SET_VAL, val });
let add_val = () => ({ type: ADD_VAL });

let reducer = (state = {
    val: 0
}, action) => {
    switch (action.type) {
        case SET_VAL:
            let num_val = Number(action.val);
            return Boolean(num_val) ? { val: action.val } : state;
        case ADD_VAL:
            return { val: Number(state.val) + 1 };
        default:
            return state;
    }
}

let App = props => {
    let { dispatch, val } = props;
    return <div className='app'>
        {/* <input type="text" value={val} onChange={e => {
            dispatch(set_val(e.target.value))
        }} /> */}
        {val}
        {' '}
        <button onClick={() => {
            dispatch(add_val())
        }}> +1 </button>
    </div>
}

App = connect(state => state)(App);


let composeEnhancer = __REDUX_DEVTOOLS_EXTENSION_COMPOSE__;
let enhancer = composeEnhancer ? composeEnhancer(applyMiddleware(logger)) : applyMiddleware(logger);
let store = createStore(reducer, enhancer);

ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById('root')
);
