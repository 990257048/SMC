// React性能优化：

// 深浅比较  https://www.jianshu.com/p/06a78b66c3a2

// 浅比较也称引用相等，在javascript中， ===是作浅比较,只检查左右两边是否是同一个对象的引用
// 深比较：对象所有属性都要相等才为true
// 单层比较：上一次与当前这次的所有属性个数，属性名，属性值（值类型或引用类型）是否一致

// 浅比较和深比较到底有哪些区别  Object.assign ... | memo useMemo useCallback | shouldComponentUpadte PureComponent

// state props变化引起DIFF，再渲染。
// props引用发生变化会引起渲染，即使状态主体内容一样，不管组件是否真的用到props。



// 正常情况渲染机制：
// 1.组件的props和state发生变化后组件就会重新渲染（正常的不是浅比较，也不是深比较），
// 2.父组件发生渲染，子组件也会重新渲染（不管是什么类型的props，不管props有没有变化）
// props引用或内容变化，都算变化（特别灵敏，容易引发不必要的渲染）

// 问题1：有时候组件并没有用到全部的props,只是用到一部分props,而没有用到的那部分props如果发生了变化，组件依然会重新渲染。
// 问题2：如果子组件的props是一个引用值，当父组件由于和该子组件不相关的props变化而引起重新渲染，子组件的props从表面看并没有变化，事实上不做任何处理的话props的引用已经变化了，因此props会比对出差异而导致组件重新渲染。

// 1.shouldComponentUpdate | memo 可以自定义组件state和props比对逻辑,用来决定组件要不要重新渲染，可以解决所有问题，可以很好地解决第一个问题，但其它问题不方便。
// 浅比较：浅比较也称引用相等，在javascript中， === 是作浅比较,只检查左右两边是否是同一个对象的引用

// 2.memo | PureComponent的比较：只比对第一层，state | props 上一次与当前这次的所有属性个数，属性名，属性值（值类型或引用类型）是否一致，一致就不渲染，不一致就渲染。
// 使用原则：确保props数据类型是值类型（乍一看跟正常组件没啥两样，但其实会避免第二种渲染机制引起的不必要的渲染）,
// 如果是引用类型，不应当有深层次(从第二层开始)的数据引用变化，若从第二层开始,某一项只是引用发生了变化，而内容与上次一样，依然会导致不能避免不必要的渲染。
// 使用场景：props最外层重新创建了（最外层引用变化了），但里面都是之前的引用或者值（里面没变），若不做任何处理该组件会重新渲染，使用memo | PureComponent之后则不会重新渲染，由于会自动进行props第一层的比较，结果没有对比出差异，从而避免这种不必要的渲染。

// 3.useMemo: 指定依赖的状态发生变化（上一次与当前这次的状态经深比较后发现差异）时，会让第一个函数执行，返回的结果（一般是引用类型的数据，由于依赖的状态发生变化而发生变化）会返回到useMemo外部，供组件使用，
// 若指定依赖并没有发生变化时，会把上一次的计算结果直接返回到useMemo外部，使引用相同，能解决第二个问题




// PureComponent会比较 Object.keys(state | props) 的长度是否一致，每一个 key是否两者都有，并且是否是一个引用，也就是只比较了第一层的值，确实很浅，所以深层的嵌套数据是对比不出来的。

// createStore connect Provider
// jsx -> ReactNode -> createElement

let reducer = (state = {
    count: 1
}, action) => {
    switch(action.type){
        case 'ADD':
            return {...state, count: state.count + 1}
        case 'REDUCE':
            return {...state, count: state.count - 1}
        case 'SET':
            return {...state, count: action.count}
        default:
            return state;
    }
}
let store = createStore(reducer);

class App extends React.Component {
    add(){
        this.props.dispatch({type: 'ADD'});
    }
    reduce(){
        this.props.dispatch({type: 'REDUCE'});
    }
    set(e){
        let count = e.target.value;
        console.log(count);
        this.props.dispatch({type: 'SET', count: Number(count)});
    }
    render(){
        let {add, reduce, set, props: {count}} = this;
        return <div>
            <input type="text" value={count} onChange={set.bind(this)}/>{' '}
            {/* <Test v="xxxx" /> */}
            <button onClick={add.bind(this)}>+</button>{' '}
            <button onClick={reduce.bind(this)}>-</button>
        </div>
    }
}
App = connect(state => {
    return {
        count: state.count
    }
})(App);

// 这3种效果一样
// class Test extends React.PureComponent {
//     render(){
//         console.log(this.props.v);
//         return <div>{this.props.v}</div>
//     }
// }
// class Test extends React.Component {
//     shouldComponentUpdate(nextProps, nextState){
//         if(nextProps.v === this.props.v){
//             return false;
//         }
//         return true;
//     }
//     render(){
//         console.log(this.props.v);
//         return <div>{this.props.v}</div>
//     }
// }
// let Test = props => {
//     console.log(props.v);
//     return <div>{props.v}</div>
// }
// Test = React.memo(Test);

ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById("root")
);