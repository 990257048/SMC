

const ALL = '所有的';
const COMPLETED = '已完成的';
const UNCOMPLETED = '未完成的';

const initState = {
    active: ALL,   // ALL | COMPLETED | UNCOMPLETED
    todoList: [
        { id: 1, content: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxx1', status: UNCOMPLETED },
        { id: 2, content: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxx2', status: UNCOMPLETED },
        { id: 3, content: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxx3', status: UNCOMPLETED },
    ]
};

let reducer = (state = initState, action) => {
    switch (action.type) {
        case ADD_TODO:
            return {
                ...state,
                todoList: [
                    {
                        id: state.todoList.length == 0 ? 1 : Math.max(...state.todoList.map(todo => todo.id)) + 1,
                        content: action.content,
                        status: UNCOMPLETED
                    },
                    ...state.todoList
                ]
            };
        case DELETE_TODO:
            return {
                ...state,
                todoList: state.todoList.filter(todo => todo.id != action.id)
            }
        case TOGGLE_TODO:
            return {
                ...state,
                active: action.active
            }
        case TOGGLE_STATUS:
            return {
                ...state,
                todoList: state.todoList.map(todo => {
                    return todo.id !== action.id ? todo : {
                        ...todo,
                        status: todo.status === COMPLETED ? UNCOMPLETED : COMPLETED
                    }
                })
            }
        default:
            return state;
    }
}

const TOGGLE_TODO = '切换到指定的当前活动的待办事项分组';
const toggleTodo = (active) => ({ type: TOGGLE_TODO, active });

const ADD_TODO = '新增指定内容的待办事项';
const addTodo = (content) => ({ type: ADD_TODO, content });

const DELETE_TODO = '删除指定ID的待办事项';
const deleteTodo = (id) => ({ type: DELETE_TODO, id });

const TOGGLE_STATUS = '切换指定ID的待办事项的当前状态';
const toggleStatus = (id) => ({ type: TOGGLE_STATUS, id });

let App = () => {
    return <div className="app">
        <h3>待办事项</h3>
        <AddTodo />
        <TodoButton />
        <TodoList />
    </div>
}

let AddTodo = props => {
    let [val, setVal] = React.useState('');
    let input = (e) => {
        setVal(e.target.value);
    }
    let add = () => {
        props.dispatch(addTodo(val));
        setVal('');
    }
    // let test = () => {
    //     props.dispatch([])
    // }
    return <div className="add-todo">
        <input type="search" value={val} onChange={input} />
        {' '}
        <button onClick={add}>添加</button>
        {' '}
        {/* <button onClick={test}>test</button> */}
    </div>
}
AddTodo = connect()(AddTodo);

let TodoButton = props => {
    let { dispatch, active } = props;
    let toggle = active => {
        dispatch(toggleTodo(active));
    }
    return <div className="todo-button">
        <button className={active == ALL ? 'active' : null} onClick={() => { toggle(ALL) }}>全部</button>
        {' '}
        <button className={active == COMPLETED ? 'active' : null} onClick={() => { toggle(COMPLETED) }}>已完成</button>
        {' '}
        <button className={active == UNCOMPLETED ? 'active' : null} onClick={() => { toggle(UNCOMPLETED) }}>未完成</button>
    </div>
}
TodoButton = connect(state => {
    return {
        active: state.active
    }
})(TodoButton);

let TodoList = props => {
    let { active, todoList } = props;
    let todoArr = React.useMemo(() => { 
        return todoList.filter(todo => (active == ALL ? true : todo.status === active))
    }, [active, todoList])
    return <div className="todo-list">
        {
            todoArr.map((todo, index) => <List key={'todo' + todo.id} NO={index + 1} {...todo} />)
        }
    </div>
}
TodoList = connect(state => state)(TodoList);

let List = props => {
    let { dispatch, NO, content, id } = props;
    return <div className="list">
        <div className="content">
            <span>{NO + '.'}</span>
            <a onClick={ () => {dispatch(toggleStatus(id))} }>{content}</a>
        </div>
        <button className="delete" onClick={() => { dispatch(deleteTodo(id)) }}>{' '}删除</button>
    </div>
}
List = connect()(List);

let composeEnhancer = __REDUX_DEVTOOLS_EXTENSION_COMPOSE__;
let enhancer = composeEnhancer ? composeEnhancer(applyMiddleware(logger)) : applyMiddleware(logger);
let store = createStore(reducer, enhancer);
let Root = <Provider store={store}><App /></Provider>
// console.log(Root);
ReactDOM.render(Root, document.getElementById('root'));
