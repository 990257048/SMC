let middleware1 = _ref => next => action => {
    console.log('middleware1 执行了');
    next(action);
}

let middleware2 = _ref => next => action => {
    console.log('middleware2 执行了');
    next(action);
}

let middleware3 = _ref => next => action => {
    console.log('middleware3 执行了');
    next(action);
}

let middlewareAPI = {
    getState(){
        return 'state';
    },
    dispatch(){
        console.log('dispatch 执行');
    }
}

let chain = [middleware1, middleware2, middleware3].map(middleware => middleware(middlewareAPI));


