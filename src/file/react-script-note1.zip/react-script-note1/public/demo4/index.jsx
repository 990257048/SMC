// 高阶组件（HOC）

// 组件复用 ref透传 传props 代理生命周期 状态 redux saga dva immutable


// immutable.js 练习
// Collection List Map Set Record Seq

// Map -- {}   List -- []有序   Set -- []无序
// Immutable对象的任何操作


let deepClone = function (obj) { //比较标准的深克隆（基本类型 对象 数组 正则 时间 文件）（用于reducer）
    if(obj === null) return null;
    if(typeof obj !== 'object') return obj;  // fn --- null {} []
    if(obj instanceof File){   //文件对象   
        return obj;
    }
    if(obj instanceof RegExp){
        return new RegExp(obj);
    }
    if(obj instanceof Date){
        return new Date(obj);
    }
    // ...有别的类型再追加
    let newObj = new obj.constructor();
    for(let key in obj){ // obj arr
        if(obj.hasOwnProperty(key)){
            newObj[key] = deepClone(obj[key]);
        }
    }
    return newObj;
}

let {Map, List, Set } = Immutable;

// List: isList | of | 
// list: get | size | set | delete | insert | update | clear | push | pop | shift | unshift | setSize | setIn | concat | merge | map | filter | 

let list = List([
    'aaa',
    'bbb',
    List(['ccc', 'ddd'])
]);

let list2 = List([
    'aaa',
    'bbb',
    ['ccc', 'ddd']
])

 




// asImmutable: ƒ asImmutable()
// asMutable: ƒ asMutable()
// clear: ƒ clear()
// concat: ƒ concat(/*...collections*/)
// constructor: ƒ List(value)
// delete: ƒ remove(index)
// deleteIn: ƒ deleteIn(keyPath)
// get: ƒ (index, notSetValue)
// insert: ƒ insert(index, value)
// map: ƒ map(mapper, context)
// merge: ƒ concat(/*...collections*/)
// mergeDeepIn: ƒ mergeDeepIn(keyPath)
// mergeIn: ƒ mergeIn(keyPath)
// pop: ƒ pop()
// push: ƒ push(/*...values*/)
// remove: ƒ remove(index)
// removeIn: ƒ deleteIn(keyPath)
// set: ƒ (index, value)
// setIn: ƒ setIn$1(keyPath, v)
// setSize: ƒ setSize(size)
// shift: ƒ shift()
// slice: ƒ slice(begin, end)
// toString: ƒ toString()
// unshift: ƒ unshift(/*...values*/)
// update: ƒ update$1(key, notSetValue, updater)
// updateIn: ƒ updateIn$1(keyPath, notSetValue, updater)
// wasAltered: ƒ wasAltered()
// withMutations: ƒ withMutations(fn)











