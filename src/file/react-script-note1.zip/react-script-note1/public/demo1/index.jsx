// 类组件 PureComponent shouldComponentUpdate memo
// 函数组件 memo useMemo useCallback

class App extends React.Component {
    constructor(...args) {
        super(...args);
        this.handleSetStep = this.handleSetStep.bind(this);
        this.handleSetCount = this.handleSetCount.bind(this);
        this.handleSetNumber = this.handleSetNumber.bind(this);
        this.state = {
            step: 0,
            count: 0,
            number: 0
        }
    }
    handleSetStep() {
        this.setState({ ...this.state, step: this.state.step + 1 });
    }
    handleSetCount() {
        this.setState({ ...this.state, count: this.state.count + 1 });
    }
    handleSetNumber() {
        this.setState({ ...this.state, number: this.state.step + this.state.count });
    }
    render() {
        let { step, count, number } = this.state;
        let { handleSetStep, handleSetCount, handleSetNumber } = this;
        return <div>
            <button onClick={handleSetStep}>step is : {step} </button>
            <button onClick={handleSetCount}>count is : {count} </button>
            <button onClick={handleSetNumber}>numberis : {number} </button>
            <hr />
            <Child step={step} count={count} number={number} />
            <hr />
            <ChildMemo step={step} count={count} number={number} />
            <ChildUseMemo step={step} count={count} number={number} />
        </div>
    }
}

class Child extends React.Component {
    render() {
        console.log(`--- re-render --- `, this.props);
        return <div>
            <p>number is : {this.props.number}</p>
        </div>
    }
}

const isEqual = (prevProps, nextProps) => {
    console.log('prev: ', prevProps, 'next: ', nextProps);
    if (prevProps.number !== nextProps.number) {
        return false;
    }
    return true;
}
class ChildMemo extends React.Component {
    render() {
        console.log(`--- memo re-render ---`);
        return <div>
            <p>number is : {this.props.number}</p>
        </div>
    }
}
ChildMemo = React.memo(ChildMemo, isEqual);


let ChildUseMemo = props => {    // useMemo细粒度优化
    return React.useMemo(() => {
        console.log(`--- memo re-render ---`);
        return <div>
            <p>number is : {props.number}</p>
        </div>
    }, [props.number])
}


ReactDOM.render(
    <App />,
    document.getElementById("root")
);