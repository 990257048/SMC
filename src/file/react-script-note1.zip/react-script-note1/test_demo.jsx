//渲染机制 生命周期 组件传参 性能优化 底层原理 经验（问题-解决方案***重要）

let {useState, useMemo, useEffect, useCallback, useContext, createContext, useReducer, useRef} = React;

// class App extends React.Component {
//     constructor(...args) {
//         super(...args);
//         this.cHandle = function () {
//             console.log(this);
//         }
//     }
//     componentWillMount(){
//         console.log('组件第一次渲染前');
//     }
//     componentDidMount(){
//         console.log('组价第一次渲染后');
//     }
//     componentWillReceiveProps(){
//         console.log('props变化前');
//     }
//     shouldComponentUpdate(){
//         console.log('组件是否渲染');
//     }
//     componentWillUpdate(){
//         console.log('组件状态发生变化，渲染前');
//     }
//     componentDidUpdate(){
//         console.log('组件状态发生变化，渲染后');
//     }
//     componentWillUnmount(){
//         console.log('组件卸载前');
//     }
//     render(){
//         console.log('组件渲染')
//         let val = this.props.val
//         return <div>
//             {val}
//             {/* <button onClick={() => {this.cHandle()} }>click me!</button> */}
//             <button onClick={ this.cHandle.bind(this) }>click me!</button>
//         </div>
//     }
// }


let App = props => {
    console.log('Fn Component run');    
    // useMemo(() => {
    //     console.log('memo每次执行');
    // });
    useMemo(() => {
        console.log('第一次渲染前');
    }, []);
    useMemo(() => {
        console.log('val发生变化后');
    }, [props.val]);
    // useEffect(() => {
    //     console.log('effect每次执行');
    // });
    useEffect(() => {
        console.log('第一次渲染后');
    }, []);
    useEffect(() => {
        console.log('val发生变化后');
    }, [props.val]);
    let handle = () => {
        props
    }
    return <div>
        {props.val}
        <button onClick={}>click me!</button>
    </div>
}

App = connect(state => {
    return {
        val: state.reducer.val
    }
})(App);





ReactDOM.render(<Provider store={store}>
    <App />
</Provider>, document.getElementById('root'));