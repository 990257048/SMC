let { useState, useEffect, useMemo, useCallback } = React;

// 始于颜值 陷于才华 忠于人品

let listen = [];
let shareData = Cmp => {
    return props => {
        let [data, setData] = useState(0);
        useEffect(() => {
            console.log('push');
            listen.push(setData);
            return () => {
                listen = listen.filter(setter => (setter != setData));
            };
        })
        return <Cmp data={data} commit={val => {
            listen.forEach(setter => setter(val));
        }} {...props} />
    }
}


// 高阶组件
// 增强组件功能 高复用

let Cmp = props => {
    let { data, commit } = props;
    return <div style={{ width: '200px', height: '60px', border: '1px solid red' }}>
        {data}
        <button onClick={() => { commit(data + 1) }}>+</button>
    </div>
}

let Cmp1 = props => {
    let { data, commit } = props;
    return <div style={{ width: '200px', height: '60px', border: '1px solid red' }}>
        {data}
        <button onClick={() => { commit(data + 1) }}>+</button>
    </div>
}

let Cmp2 = props => {
    let { data, commit } = props;
    return <div style={{ width: '200px', height: '60px', border: '1px solid red' }}>
        {data}
        <button onClick={() => { commit(data + 1) }}>+</button>
    </div>
}

Cmp1 = shareData(Cmp);
Cmp2 = shareData(Cmp);

let App = () => {
    return <div>
        hello world
        <Cmp1 />
        <Cmp2 />
    </div>
}

ReactDOM.render(<App />, document.getElementById('root'));
