
let App = () => {
    return <div>hello react</div>
}

ReactDOM.render(<App />, document.getElementById('root'));
