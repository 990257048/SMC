
// Component | shouldComponentUpdate | PureComponent | memo | useMemo
// 浅比较 深比较

// 情况：使用shouldComponentUpdate优化性能

let { Component, useState, useMemo, useCallback } = React;

// class App extends Component {
//     constructor(...args) {
//         super(...args);
//         this.state = {
//             v: 0
//         };
//         this.add = this.add.bind(this);
//         this.reduce = this.reduce.bind(this);
//         this.set = this.set.bind(this);
//     }
//     add() {
//         this.setState({ ...this.state, v: this.state.v + 1 });
//     }
//     reduce() {
//         this.setState({ ...this.state, v: this.state.v - 1 });
//     }
//     set(v) {
//         this.setState({ ...this.state, v });
//     }
//     render() {
//         return <Cpn {...this} />
//     }
// }

// class Cpn extends Component {
//     render() {
//         console.log(this.props);
//         return <div>
//             test
//         </div>
//     }
// }


// let App = () => {
//     const [name, setName] = useState('名称')
//     const [content, setContent] = useState('内容')
//     return <div>
//         <button onClick={() => setName(new Date().getTime())}>name</button>
//         <button onClick={() => setContent(new Date().getTime())}>content</button>
//         <Button name={name}>{content}</Button>
//     </div>
// }

// let Button = ({ name, children }) => {
//     let changeName = (name) => {
//         console.log('11');
//         return name + '改变name的方法';
//     }
//     // let otherName = changeName(name);
//     // 使用useMemo
//     let otherName = useMemo(() => changeName(name), [name]);
//     return <div>
//         <div>{otherName}</div> 
//         <div>{children}</div>
//     </div>
// }

let debounce = (fn, delay) => {
    let timer = null;
    return (...args) => {
        if (timer) {
            clearTimeout(timer);
        }
        timer = setTimeout(() => {
            console.log('run-do', args[0]);
            fn(...args)
        }, delay);
    }
}

// let App = () => {
//     let [count, setCount] = useState(0);
//     let [bounceCount, setBounceCount] = useState(0);
//     setBounceCount = debounce(setBounceCount, 1000); // 错误操作
//     let mouseMoveHandle = () => {
//         setCount(count + 1);
//         setBounceCount(bounceCount + 1);
//     }
//     return <div onMouseMove={mouseMoveHandle}>
//         普通移动次数:{count}
//         防抖后移动次数:{bounceCount}
//     </div>
// }

let App = () => {
    let [count, setCount] = useState(0);
    let [bounceCount, setBounceCount] = useState(0);
    // setBounceCount = useMemo(() => debounce(setBounceCount, 1000), []); // 正确操作1
    setBounceCount = useCallback(debounce(setBounceCount, 1000), []); // 正确操作2
    let mouseMoveHandle = () => {
        setCount(count + 1);
        setBounceCount(bounceCount + 1);
    }
    return <div onMouseMove={mouseMoveHandle}>
        普通移动次数:{count}
        <br />
        防抖后移动次数:{bounceCount}
    </div>
}

ReactDOM.render(<App />, document.getElementById('root'));
