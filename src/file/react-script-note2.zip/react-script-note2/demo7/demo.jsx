// todolist
let { useState, useEffect, useMemo } = React;
let { Provider, connect, useSelector, useDispatch } = ReactRedux;
let { createStore, applyMiddleware } = Redux;


const ALL = '全部';
const COMPLETED = '已完成';
const UNCOMPLETED = '未完成';

// actionName | actionCreator
const ADD_ITEM = '添加一项';
const add_item = (content) => ({ type: ADD_ITEM, content });

const TOGGLE_LIST = '切换列表';
const toggle_list = (current) => ({ type: TOGGLE_LIST, current });

const TOGGLE_ITEM_STATUS = '切换一项的状态';
const toggle_item_status = (id) => ({ type: TOGGLE_ITEM_STATUS, id });

const DELETE_ITEM = '删除一项';
const delete_item = (id) => ({ type: DELETE_ITEM, id });

let initState = {
    current: ALL,   // ALL COMPLETED UNCOMPLETED
    list: [
        { id: 1, status: UNCOMPLETED, content: '这是一条测试数据' },
    ]
};

let reducer = (state = initState, action) => {
    // 添加item  切换list  切换item状态  删除item
    switch (action.type) {
        case ADD_ITEM:
            var { content } = action;
            return {
                ...state,
                list: [
                    { id: state.list.length == 0 ? 1 : Math.max(...state.list.map(item => item.id)) + 1, status: UNCOMPLETED, content },
                    ...state.list
                ]
            };
        case TOGGLE_LIST:
            var { current } = action;
            return {
                ...state,
                current
            };
        case TOGGLE_ITEM_STATUS:
            var { id } = action;
            return {
                ...state,
                list: state.list.map(item => {
                    return item.id != id ? item : { ...item, status: item.status == COMPLETED ? UNCOMPLETED : COMPLETED }
                })
            };
        case DELETE_ITEM:
            var { id } = action;
            return {
                ...state,
                list: state.list.filter(item => item.id !== id)
            };
        default:
            return state;
    }
}

let enhancer = applyMiddleware(thunk);
let composeEnhancer = __REDUX_DEVTOOLS_EXTENSION_COMPOSE__;
enhancer = composeEnhancer ? composeEnhancer(enhancer) : enhancer;
let store = createStore(reducer, enhancer);

let App = () => {
    return <div id='app'>
        <AddTodo />
        <Btns />
        <TodoList />
    </div>
}

let AddTodo = props => {
    let { dispatch } = props;
    let [content, setContent] = useState('');
    let add = () => {
        dispatch(add_item(content));
        setContent('');
    }
    return <div className='add-todo'>
        <input type="search" value={content} onChange={e => { setContent(e.target.value) }} />
        {' '}
        <button onClick={add}>ADD</button>
        <hr />
    </div>
}
AddTodo = connect()(AddTodo);

let Btns = (props) => {
    let { current, dispatch } = props;
    return <div className='btns'>
        <button style={{ color: current == ALL ? 'red' : null }} onClick={() => { dispatch(toggle_list(ALL)) }}>全部的</button>
        {' '}
        <button style={{ color: current == COMPLETED ? 'red' : null }} onClick={() => { dispatch(toggle_list(COMPLETED)) }}>已完成</button>
        {' '}
        <button style={{ color: current == UNCOMPLETED ? 'red' : null }} onClick={() => { dispatch(toggle_list(UNCOMPLETED)) }}>未完成</button>
    </div>
}
Btns = connect(state => ({ current: state.current }))(Btns);

let TodoList = (props) => {
    let { current, list } = props;
    let List = useMemo(() => {
        let listData = current == ALL ? list : list.filter(item => item.status == current);
        return listData.map(item => <TodoItem {...{ ...item, key: item.id }} />)
    }, [current, list]);
    return <div className='todo-list'>
        <ul>
            {List}
        </ul>
    </div>
}
TodoList = connect(state => state)(TodoList);

let TodoItem = (props) => {
    let { dispatch, id, content } = props;
    return <li className='todo-item'>
        <p onClick={() => { dispatch(toggle_item_status(id)) }}>{content}</p>
    </li>
}
TodoItem = connect()(TodoItem);

ReactDOM.render(<Provider store={store}>
    <App />
</Provider>, document.getElementById('root'));
