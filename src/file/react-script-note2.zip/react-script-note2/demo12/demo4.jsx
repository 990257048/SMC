let { useState, useEffect, useMemo, useRef, forwardRef } = React;
// useRef: 拿到原生节点的引用
// forwardRef: 可以让组件对外暴露任何一个东西（可以是原生节点，数据等等），ref能穿透组件

// class Component
// 字符串ref  比较被动 只能去一个固定地方（this.refs）拿（要注意时机） 死的
// 函数ref    很主动，会主动执行 活的

let Cmp = forwardRef((_, ref) => {
    let [v, setV] = useState(0);
    useEffect(() => {
        let timer = setInterval(() => {
            setV(v + 1);
        }, 1000);
        return () => {
            clearInterval(timer);
        };
    }, [v])
    return <div>
        {/* <input type="text" defaultValue={v} ref={ref} />  这个不能*/}
        {v}
        <button ref={ref}>{v}</button>
    </div>
})

let App = () => {
    let ipt = useRef();
    let cmp = useRef();

    return <div>
        <Cmp ref={cmp} />
        <input type="text" ref={ipt} />
        <button onClick={() => { console.log(ipt.current, cmp.current) }}>click me</button>
    </div>
}

ReactDOM.render(<App />, document.getElementById('root'));
