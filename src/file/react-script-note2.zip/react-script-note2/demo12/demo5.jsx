
let { useState, useEffect, createRef, useRef, forwardRef } = React;
// useRef: 拿到原生节点的引用
// forwardRef: 可以让组件对外暴露任何一个东西（可以是原生节点，数据等等），ref能穿透组件

// class Component
// 字符串ref  比较被动 只能去一个固定地方（this.refs）拿（要注意时机）会降低性能（程序要主动把原生节点放在一个地方） 不灵活 死的
// 函数ref    很主动，会主动执行(注意执行时机) 活的
// createRef  相当于 useRef


class App extends React.Component {
    constructor(...args) {
        super(...args);
        this.ipt = React.createRef();
        this.state = {
            v: 0
        };
    }
    componentDidMount() {
        console.log('Did Mount!');
        console.log(this, this.refs.ipt, this.ipt.current);
        this.addV();
    }
    addV() {
        this.setState(_ => {
            _.v++;
            return _;
        });
    }
    fn_ref(ipt) {
        // 第一次创建好ref后执行
        // 组件状态改变后会执行（重要：会执行2次，第一次ipt是null，第二次才是原生元素） 
        console.log(this, ipt);
    }
    render() {
        return <div>
            <input type="text" ref={this.fn_ref.bind(this)} />
            <input type="text" ref="ipt" />
            <input type="text" ref={this.ipt} />
            {this.state.v}

            <button onClick={this.addV.bind(this)}>click me!</button>
        </div>
    }
}

ReactDOM.render(<App />, document.getElementById('root'));
