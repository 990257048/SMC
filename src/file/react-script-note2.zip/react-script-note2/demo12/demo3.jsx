let { useState, useEffect, useMemo } = React;

// 一个异步操作，要等很久
// 比如请求数据，数据回来后要设置state, 但是这个时候组件已经卸载
// 那么就会引起资源泄露，组件虽然卸载，但是setState还在，还能setState

// let Cmp1 = () => {
//     let [v, setV] = useState(0);
//     useEffect(() => {
//         setTimeout(() => {
//             setV(v + 1);
//         }, 1000);
//     });
//     // 点击卸载后的警告 (组件已经卸载，还在设置新状态，造成内存泄露)
//     // Warning: Can't perform a React state update on an unmounted component.This is a no-op, but it indicates a memory leak in your application. To fix, cancel all subscriptions and asynchronous tasks in a useEffect cleanup function.
//     // 无法对未安装的组件执行反应状态更新。这是不操作，但表示应用程序内存泄漏。若要修复，请取消useffect清除函数中的所有订阅和异步任务。
//     return <div>{v}</div>
// }

let Cmp1 = () => {
    let [v, setV] = useState(0);
    useEffect(() => {
        let timer = setTimeout(() => {
            setV(v + 1);
        }, 1000);
        return () => {
            clearTimeout(timer);
        }
    });
    // 正常的做法,保证组件卸载了就清除掉任务,就不会内存泄露了
    return <div>{v}</div>
}

let App = () => {
    let [flag, setFlag] = useState(true);

    return <div>
        {flag ? <Cmp1 /> : ''}
        <button onClick={() => { setFlag(false) }}>卸载</button>
    </div>
}

ReactDOM.render(<App />, document.getElementById('root'));
