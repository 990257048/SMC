let { useState, useEffect, useMemo } = React;

let App = () => {
    let [data, setData] = useState(null);
    useEffect(() => {
        console.log('effect');
        getData().then(res => setData(res));
    });
    // Bailing out 机制 （保释 摆脱困境）
    // state设置重复的值只会多重复渲染一次 
    // 设置相同的值时react会多给一次机会，
    // 第一次设置相同(如果设置的是引用值的话，引用要相同才叫相同)的值依然会再渲染一次，但这一次渲染完毕后不会再进到effect中
    // 第二次再设置相同的值则不会再渲染了，react会认为state不会再变化了
    console.log('render', data);
    return <div> hello react </div>
}

let data = [
    { name: 'gao', age: 18 },
    { name: 'huang', age: 18 }
]
let getData = () => new Promise((resolve) => {
    // let data = [  不能用这个data,每次会重新创建data,导致每次data引用不同
    //     { name: 'gao', age: 18 },
    //     { name: 'huang', age: 18 }
    // ]
    setTimeout(() => {
        resolve(data);
    }, 0);
});

ReactDOM.render(<App />, document.getElementById('root'));
