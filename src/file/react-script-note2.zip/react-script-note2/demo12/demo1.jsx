let { useState, useEffect, useMemo } = React;
let App = () => {
    let [data, setData] = useState(0);
    console.log('render', data);
    return <div>
        {data}
        <button onClick={e => { setData(1) }}>click me!</button>
        {/* 
            state设置重复的值只会多重复渲染一次 
            设置相同的值时react会多给一次机会，第一次设置相同的值依然会再渲染一次，第二次再设置相同的值则不会再渲染了
        */}
    </div>
}


ReactDOM.render(<App />, document.getElementById('root'));
