// setState同步与异步

class Example extends React.Component {
    constructor() {
        super();
        this.state = {
            val: 0
        };
    }

    componentDidMount() {
        // setState另一种写法，会基于上次的结果来改变
        this.setState((prev) => {
            prev.val += 1;
            return prev;
        });
        console.log(this.state.val);    // 0

        this.setState((prev) => {
            prev.val += 1;
            return prev;
        });
        console.log(this.state.val);    // 0

        setTimeout(() => {   // 这里setState是同步的
            this.setState({ val: this.state.val + 1 });
            console.log(this.state.val);  // 3

            this.setState({ val: this.state.val + 1 });
            console.log(this.state.val);  // 4
        }, 0);
    }

    render() {
        return <div>hello react</div>;
    }
};

ReactDOM.render(<Example />, document.getElementById('root'))

