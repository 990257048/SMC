// setState同步与异步

class Example extends React.Component {
    constructor() {
        super();
        this.state = {
            val: 0
        };
    }

    componentDidMount() {
        this.setState({ val: this.state.val + 1 });   // 这里setState是异步的
        console.log(this.state.val);    // 0

        this.setState({ val: this.state.val + 1 });    // 这里setState是异步的
        console.log(this.state.val);    // 0

        setTimeout(() => {   // 这里setState是同步的
            this.setState({ val: this.state.val + 1 });
            console.log(this.state.val);  // 2

            this.setState({ val: this.state.val + 1 });
            console.log(this.state.val);  // 3
        }, 0);
    }

    render() {
        return <div>hello react</div>;
    }
};

ReactDOM.render(<Example />, document.getElementById('root'))

