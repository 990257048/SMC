
let { createStore, applyMiddleware, combineReducers, bindActionCreators } = Redux;

// middleware: _ref => next => action => {...}

// middleware为什么要写成这样？ middleware: _ref => next => _dispatch
// _ref: 用于传进getState(方便拿到全局状态)和dispatch（store中原本的dispatch）
// next： 用于传进执行下一个中间件的函数
// _dispatch: 用于compose返回增强后的dispatch

let middleware1 = _ref => next => action => {
    console.log('第一个中间件执行，action: ', action);
    next(action);
}

let middleware2 = _ref => next => action => {
    console.log('第二个中间件执行，action: ', action);
    next(action);
}

let middleware3 = _ref => next => action => {
    console.log('第三个中间件执行，action: ', action);
    next(action);
}

// actionCreators
let SET_STATE = '设置状态';

let setState = test => ({ type: SET_STATE, test });

// reducers
let rootReducers = (state = { test: 'test' }, action) => {
    switch (action.type) {
        case SET_STATE:
            return { ...state, test: action.test }
        default:
            return state;
    }
}

// applyMiddleware: 高阶增强器
// enhancer: store增强器（这里只增强store.dispatch）
let dispatchEnhancer = createStore => (...args) => { //模拟applyMiddleware的增强效果
    let store = createStore(...args);
    let middlewareAPI = {
        getState: store.getState,
        dispatch: action => _dispatch(action)
    }
    let chain = [middleware1, middleware2, middleware3].map(middleware => middleware(middlewareAPI));
    let _dispatch = compose(chain)(store.dispatch);
    return {
        ...store,
        dispatch: _dispatch
    }
}

// compose: 高阶的dispatch创建器
let compose = chain => {
    // chain: [
    //     next => action => { f1(_ref, next, action) },
    //     next => action => { f2(_ref, next, action) },
    //     next => action => { f3(_ref, next, action) },
    // ]
    switch (chain.length) {
        case 0:
            return dispatch => dispatch;  // 不增强，把原本的dispatch不做任何处理返回
        case 1:
            return chain[0];  // next指定成原本的dispatch
        default:
            return chain.reduce((prev, next) => dispatch => prev(next(dispatch)));
        // 1. dispatch => chain[0](chain[1](dispatch))
        // 2. dispatch => chain[0](chain[1](chain[2](dispatch)))
        // 3. dispatch => chain[0](chain[1](chain[2](chain[3](dispatch))))
        // 。。。
    }
}

// store: {getState, dispatch, subscribe}
let store = createStore(rootReducers, dispatchEnhancer);

// let enhancer = applyMiddleware(thunk)(createStore)(reducer, enhancer)

console.log(store);
// 订阅事件
store.subscribe(() => {
    console.log('状态变化了1', store.getState());
})
store.subscribe(() => {
    console.log('状态变化了2', store.getState());
})
store.subscribe(() => {
    console.log('状态变化了3', store.getState());
})

// 三秒后改变全局状态
setTimeout(() => {
    store.dispatch(setState('new test'));
}, 3000);
