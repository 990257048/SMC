// 异步

// async function async1() {
//     console.log('async1 start');  // 2
//     await async2();
//     console.log('async1 end');  // 6
// }
// async function async2() {
//     console.log('async2');  // 3
// }
// console.log('script start');   // 1
// setTimeout(function () {
//     console.log('setTimeout');  // 8
// }, 0)
// async1();
// new Promise(function (resolve) {
//     console.log('promise1');   // 4
//     resolve();
// }).then(function () {
//     console.log('promise2');  // 7
// });
// console.log('script end');  // 5


async function async1() {
    console.log('async1 start');  // 2
    await async2();
    console.log('async1 end');  // 8
}
async function async2() {
    //async2做出如下更改：
    new Promise(function (resolve) {
        console.log('promise1');    // 3
        resolve();
    }).then(function () {
        console.log('promise2');  // 6
    });
}
console.log('script start');   // 1

setTimeout(function () {
    console.log('setTimeout');  // 9
}, 0)
async1();

new Promise(function (resolve) {
    console.log('promise3');  // 4
    resolve();
}).then(function () {
    console.log('promise4');  // 7
});

console.log('script end');  // 5
