let { useState, useEffect, useMemo, useCallback } = React;
// 自定义hook
// 1.对外提供状态，内部维护状态，自发的更新状态，不需要外部参与维护
// 2.由外部来维护状态
// 3.对组件生命周期的控制，特定的时间做特定的事
// 4.对特殊组件（具有复杂功能的组件）定制专门的hook，完成封装特定的功能模块
// 路由 全局状态 生命周期 特殊状态 状态变化的响应
// 可配合：useState useEffect useMemo useCallback useSelector useDispatch useReducer


let useXXX = () => {
    // 表单 表格

    // 如何为组件定制hook

    // 如何做到复用
    useEffect(() => {
        console.log('componentDidMount');
    }, []);
}

let App = () => {
    useXXX();
    return <div>
        hallo react
    </div>
}

ReactDOM.render(<App />, document.getElementById('root'));
