let { useState, useEffect, useMemo, useCallback } = React;

// 使用useMemo避免无效的计算

let App = () => {
    let [a, setA] = useState(0);
    let [b, setB] = useState(0);
    let [c, setC] = useState(0);

    // let d = a + b;         // 错误做法
    let d = useMemo(() => {   // 正确做法
        console.log('计算a+b');
        return a + b;
    }, [a, b]);
    return <div>
        hello world
        <input type="text" value={a} onChange={e => { setA(Number(e.target.value)) }} />
        +
        <input type="text" value={b} onChange={e => { setB(Number(e.target.value)) }} />
        =
        {d}
        <br />
        {c}
        <button onClick={() => { setC(c + 1) }}>+</button>
    </div>
}

ReactDOM.render(<App />, document.getElementById('root'));
