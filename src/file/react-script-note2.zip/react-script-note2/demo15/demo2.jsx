let { useState, useEffect, useMemo, useCallback, memo } = React;

// useMemo memo用法
// 1.避免不必要的计算开销 useMemo
// 2.避免（由于状态的引用变化而内容未发生变化引起的）不必要的渲染 useMemo + memo

// 结论：FC
// 结论1.父组件重新渲染，子组件必重新渲染, 即使该子组件不依赖任何状态
// 解决1.子组件使用memo, 用来保证子组件是由于的props发生了变化而引起的重新渲染，而不是只由于父组件重新渲染而引起的重新渲染（因为这种渲染没有意义，结果是一样的）
// 结论2.子组件使用了memo, 其依赖的状态是引用值，当该引用值的引用发生变化而内容未发生变化（{a:'a'} == {a:'a'} --> false）依然会引起子组件重新渲染（因为这种渲染没有意义，结果是一样的）
// 解决2.在父组件中把子组件依赖的引用值用useMemo, 保证必要的时候再重新计算该引用值，不必要的时候直接拿缓存中的引用值，使引用值的引用与上次相同

let Son1 = props => {
    console.log('son1 rerender!');
    return <div>子组件1: 未使用memo</div>
}

let Son2 = props => {
    console.log('son2 rerender!');
    return <div>子组件2: 使用了memo，props是引用值，未使用useMemo处理</div>
}
Son2 = memo(Son2);

let Son3 = props => {
    console.log('son3 rerender!');
    return <div>子组件3: 使用了memo，props是引用值，使用了useMemo处理</div>
}
Son3 = memo(Son3);

let App = () => {
    let [a, setA] = useState(0);
    let [b, setB] = useState(0);
    let [c, setC] = useState(0);

    let d = useMemo(() => {
        console.log('重新计算d: a+b');
        return a + b;
    }, [a, b]);
    console.log('重新计算d0: {a, b}');
    let d0 = { a, b };            // 错误做法
    let d1 = useMemo(() => {     // 正确做法
        console.log('重新计算{a, b}');
        return { a, b };
    }, [a, b]);

    return <div>
        hello react
        <hr />
        <input type="text" value={a} onChange={e => { setA(Number(e.target.value)) }} />
        {' '}+{' '}
        <input type="text" value={b} onChange={e => { setB(Number(e.target.value)) }} />
        {' '}={' '}
        {d}
        <hr />
        {c}{' '}
        <button onClick={() => { setC(c + 1) }}>+</button>
        <hr />
        <Son1 />
        <Son2 d0={d0} />
        <Son3 d1={d1} />
    </div>
}

ReactDOM.render(<App />, document.getElementById('root'));
